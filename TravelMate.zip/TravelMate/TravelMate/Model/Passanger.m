//
//  Passanger.m
//  TravelMate
//
//  Created by Hrishikesh  Pol on 11/11/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import "Passanger.h"


@implementation Passanger

@dynamic name;
@dynamic dob;
@dynamic sex;
@dynamic emailID;
@dynamic mobileNo;
@dynamic photoUrl;

@end
