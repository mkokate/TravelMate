//
//  City.m
//  TravelMate
//
//  Created by Hrishikesh  Pol on 11/11/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import "City.h"


@implementation City

@dynamic name;
@dynamic latitude;
@dynamic longitude;
@dynamic majorCity;

@end
