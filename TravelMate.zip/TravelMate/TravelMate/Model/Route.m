//
//  Route.m
//  TravelMate
//
//  Created by Hrishikesh  Pol on 11/11/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import "Route.h"


@implementation Route

@dynamic routeID;
@dynamic fromLocation;
@dynamic toLocation;
@dynamic intermediate;

@end
