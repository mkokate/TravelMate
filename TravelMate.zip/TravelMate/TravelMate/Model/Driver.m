//
//  Driver.m
//  TravelMate
//
//  Created by Hrishikesh  Pol on 11/11/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import "Driver.h"


@implementation Driver

@dynamic name;
@dynamic dob;
@dynamic sex;
@dynamic emailID;
@dynamic address;
@dynamic mobileNo;
@dynamic smoker;
@dynamic drivingLicNo;
@dynamic photoUrl;

@end
