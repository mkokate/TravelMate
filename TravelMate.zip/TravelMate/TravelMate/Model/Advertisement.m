//
//  Advertisement.m
//  TravelMate
//
//  Created by Hrishikesh  Pol on 11/11/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import "Advertisement.h"


@implementation Advertisement

@dynamic serialNo;
@dynamic mobileNo;
@dynamic fromLocation;
@dynamic toLocation;
@dynamic intermediate;
@dynamic carID;
@dynamic price;
@dynamic startTime;
@dynamic endTime;

@end
