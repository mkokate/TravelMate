//
//  Car.m
//  TravelMate
//
//  Created by Hrishikesh  Pol on 11/11/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import "Car.h"


@implementation Car

@dynamic carID;
@dynamic name;
@dynamic model;
@dynamic type;
@dynamic isAC;
@dynamic mobileNo;
@dynamic photo1ID;
@dynamic photo2ID;

@end
