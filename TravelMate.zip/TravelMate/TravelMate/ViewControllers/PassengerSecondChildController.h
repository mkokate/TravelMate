//
//  PassengerSecondChildController.h
//  TravelMate
//
//  Created by Mahesh on 11/9/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PassengerSecondChildController : UIViewController

@property (strong, nonatomic) XCDFormInputAccessoryView *inputAccessoryView;

@end
