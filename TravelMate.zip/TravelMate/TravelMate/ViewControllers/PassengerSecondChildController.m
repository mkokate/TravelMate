//
//  PassengerSecondChildController.m
//  TravelMate
//
//  Created by Mahesh on 11/9/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import "PassengerSecondChildController.h"

@interface PassengerSecondChildController ()

@property (weak, nonatomic) IBOutlet UITextField *txtJorneyDate;
@property (weak, nonatomic) IBOutlet UITextField *txtJorneyTime;

@end

@implementation PassengerSecondChildController

-(void)viewDidLoad
{
    [super viewDidLoad];
    self.inputAccessoryView = [XCDFormInputAccessoryView new];
}

@end
