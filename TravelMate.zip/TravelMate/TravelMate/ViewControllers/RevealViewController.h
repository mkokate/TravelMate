//
//  RevealViewController.h
//  Reveal
//
//  Created by Patrick McConnell on 3/31/12.
//  Copyright (c) 2012 Dogboy Studios. All rights reserved.
//

#import "ZUUIRevealController.h"

@interface RevealViewController : ZUUIRevealController<ZUUIRevealControllerDelegate>

@end
