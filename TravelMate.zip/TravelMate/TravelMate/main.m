//
//  main.m
//  TravelMate
//
//  Created by Hrishikesh  Pol on 05/11/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
