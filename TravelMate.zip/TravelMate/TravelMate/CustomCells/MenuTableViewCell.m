//
//  MenuTableViewCell.m
//  TravelMate
//
//  Created by Hrishikesh  Pol on 10/11/14.
//  Copyright (c) 2014 Hrishikesh  Pol. All rights reserved.
//

#import "MenuTableViewCell.h"

@implementation MenuTableViewCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
